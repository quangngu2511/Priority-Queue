#include <fstream>
#include <iostream>

using namespace std;

struct Node {
    int data;
    int prn;
    Node *next;
};

class PQ_LinkedList {
private:
    Node *head;

public:
    PQ_LinkedList() {
        head = NULL;
    }

    void enqueue(int d, int p) {
        Node *newNode = new Node();
        newNode->data = d;
        newNode->prn = p;
        newNode->next = NULL;

        if (head == NULL || p < head->prn) {
            newNode->next = head;
            head = newNode;
        } else {
            Node *current = head;
            while (current->next != NULL && current->next->prn <= p) {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
        }
    }

    int dequeue() {
        if (head == NULL)
            return -1;

        Node *temp = head;
        int resultData = temp->data;
        head = head->next;

        delete temp;
        return resultData;
    }

    bool isEmpty() {
        return head == NULL;
    }
};

int main() {
    ifstream inputFile("input_list.txt");
    ofstream outputFile("output_list.txt");

    if (!inputFile.is_open() || !outputFile.is_open())
        return 1;

    PQ_LinkedList pq;
    string op;
    int d, p;

    while (inputFile >> op) {
        if (op == "ENQUEUE") {
            inputFile >> d >> p;
            pq.enqueue(d, p);
            outputFile << "Enqueued: " << d << " (Priority: " << p << ")\n";
        } else if (op == "DEQUEUE") {
            if (!pq.isEmpty())
                outputFile << "Dequeued: " << pq.dequeue() << "\n";
            else
                outputFile << "Queue is empty\n";
        }
    }
    return 0;
}