#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

struct HeapNode {
    string value;
    int priority;
};

class PQ_BinaryHeap {
private:
    HeapNode *arr;
    int size;
    int capacity;

public:
    PQ_BinaryHeap(int cap) {
        this->capacity = cap;
        this->size = 0;
        this->arr = new HeapNode[capacity];
    }

    ~PQ_BinaryHeap() {
        delete[] arr;
    }

    int parent(int i) {
        return (i - 1) / 2;
    }
    int leftChild(int i) {
        return 2 * i + 1;
    }
    int rightChild(int i) {
        return 2 * i + 2;
    }

    void enqueue(string val, int p) {
        if (size == capacity)
            return;

        size++;
        int i = size - 1;
        arr[i].value = val;
        arr[i].priority = p;

        while (i != 0 && arr[parent(i)].priority > arr[i].priority) {
            swap(arr[i], arr[parent(i)]);
            i = parent(i);
        }
    }

    string dequeue() {
        if (size <= 0)
            return "No tasks";
        if (size == 1) {
            size--;
            return arr[0].value;
        }

        string rootValue = arr[0].value;

        arr[0] = arr[size - 1];
        size--;

        minHeapify(0);

        return rootValue;
    }

    void minHeapify(int i) {
        int smallest = i;
        int l = leftChild(i);
        int r = rightChild(i);

        if (l < size && arr[l].priority < arr[smallest].priority)
            smallest = l;
        if (r < size && arr[r].priority < arr[smallest].priority)
            smallest = r;

        if (smallest != i) {
            swap(arr[i], arr[smallest]);
            minHeapify(smallest);
        }
    }
};

int main() {
    ifstream inputFile("input_task.txt");
    ofstream outputFile("output_task.txt");

    if (!inputFile.is_open() || !outputFile.is_open())
        return 1;

    PQ_BinaryHeap scheduler(100);
    string op, taskName;
    int p;

    while (inputFile >> op) {
        if (op == "ADD_TASK") {
            inputFile >> taskName >> p;
            scheduler.enqueue(taskName, p);
            outputFile << "Added Task: " << taskName << " (Priority: " << p << ")\n";
        } else if (op == "DO_TASK") {
            string task = scheduler.dequeue();
            if (task != "No tasks")
                outputFile << "Doing Task: " << task << "\n";
            else
                outputFile << "No tasks available to do.\n";
        }
    }
    return 0;
}