#include <fstream>
#include <iostream>

using namespace std;

struct Element {
    int data;
    int priority;
};

class PQ_UnsortedArray {
private:
    Element *arr;
    int capacity;
    int size;

public:
    PQ_UnsortedArray(int cap) {
        this->capacity = cap;
        this->size = 0;
        this->arr = new Element[capacity];
    }

    ~PQ_UnsortedArray() {
        delete[] arr;
    }

    void enqueue(int d, int p) {
        if (size == capacity)
            return;

        arr[size].data = d;
        arr[size].priority = p;
        size++;
    }

    int dequeue() {
        if (size == 0)
            return -1;

        int minPriorityIndex = 0;
        for (int i = 1; i < size; i++) {
            if (arr[i].priority < arr[minPriorityIndex].priority) {
                minPriorityIndex = i;
            }
        }

        int resultData = arr[minPriorityIndex].data;

        for (int i = minPriorityIndex; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }

        size--;
        return resultData;
    }

    bool isEmpty() {
        return size == 0;
    }
};

int main() {
    ifstream inputFile("input_array.txt");
    ofstream outputFile("output_array.txt");

    if (!inputFile.is_open() || !outputFile.is_open())
        return 1;

    PQ_UnsortedArray pq(100);
    string op;
    int d, p;

    while (inputFile >> op) {
        if (op == "ENQUEUE") {
            inputFile >> d >> p;
            pq.enqueue(d, p);
            outputFile << "Enqueued: " << d << " (Priority: " << p << ")\n";
        } else if (op == "DEQUEUE") {
            if (!pq.isEmpty())
                outputFile << "Dequeued: " << pq.dequeue() << "\n";
            else
                outputFile << "Queue is empty\n";
        }
    }
    return 0;
}